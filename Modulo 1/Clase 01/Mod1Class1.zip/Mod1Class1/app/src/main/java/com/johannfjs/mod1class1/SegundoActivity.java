package com.johannfjs.mod1class1;

import android.app.Activity;

/**
 * Created by johannfjs on 26/05/15.
 */
public class SegundoActivity extends Activity {
}
